//
//  GameView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct GameView: View {
    var game:Game
    var body: some View {
        ZStack {
            
        
            Rectangle()
                .foregroundColor(.white)
                .cornerRadius(20)
                .shadow(color:.gray, radius:  5)
            
            VStack(alignment: .center) {
                HStack(alignment: .center) {
                    Spacer()
                    
                    
                    
                    InfoColumnView(team: game.HomeTeam, score: game.HomeTeamScore)
                    
                    
                    Spacer()
                    Text("VS")
                    Spacer()
                    
                    InfoColumnView(team: game.AwayTeam, score: game.AwayTeamScore)
                    Spacer()
                }
               
                
        
                HStack {
                    Text(game.Status)
                    if (game.Status == "Scheduled") {
                        if let dateTime = game.DateTime {
                            Text("@ " + DateHelper.getTimeString(time: dateTime))
                        } else {
                            Text("Cancelled")
                        }
                        
                    }
                }
            }
            .padding()
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView(game: Constants.futureGame)
    }
}
