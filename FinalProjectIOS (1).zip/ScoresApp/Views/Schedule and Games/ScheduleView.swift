//
//  ScheduleView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct ScheduleView: View {
    
    
    @ObservedObject var model:DataModel
    
    var body: some View {
        ZStack {
            
            // Backdrop color
            Color("backdrop")
                .ignoresSafeArea()
            
            
            ScrollView {
                LazyVStack(spacing: 20) {
                    
             
                    HStack{
                        Text("Games")
                            .font(.largeTitle)
                            .bold()
                        Spacer()
                        Image("nba")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 70, height: 60, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    }
                    
            
                    Picker(selection: $model.selectedDay, label: Text(""), content: {
                        Text("Yesterday").tag(DateCategory.yesterday)
                        Text("Today").tag(DateCategory.today)
                        Text("Tomorrow").tag(DateCategory.tomorrow)
                    })
                    .pickerStyle(SegmentedPickerStyle())
                    
                    
            
                    if let sched = model.scheduleDict[model.selectedDay] {
                        
                        
                        
                        ForEach(sched!.games) { game in
                            if (game.HomeTeamID == model.favouriteTeam ||
                                    game.AwayTeamID == model.favouriteTeam) && game.Status != "Canceled" {
                                
                                
                                FavouriteGameView(game: game, teamName: Constants.teamNames[model.favouriteTeam])
                                Divider()
                            }
                        }
                        
                        
                        
                        ForEach(sched!.games) { game in
                            if game.HomeTeamID != model.favouriteTeam &&
                                game.AwayTeamID != model.favouriteTeam &&
                                game.Status != "Canceled" {
                                GameView(game: game)
                            }
                        }
                        
                        
                      
                        let gamesCount = sched!.games.count
                        if gamesCount == 1 {
                            Text("\(gamesCount) Game")
                                .bold()
                        } else {
                            Text("\(gamesCount) Games")
                                .bold()
                                .padding(.bottom)
                        }
                        
                    } else {
                        Text("Null Schedule Instance")
                            .bold()
                    }
                }
                .padding(.horizontal)
            }
        }
    }
    
    
    
    init(model: DataModel) {
        self.model = model
        UISegmentedControl.appearance().selectedSegmentTintColor = .red
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.black], for: .normal)
    }
}

struct ScheduleView_Previews: PreviewProvider {
    static var previews: some View {
        ScheduleView(model: DataModel())
    }
}
