//
//  FavouriteGameView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct FavouriteGameView: View {
    var game:Game
    var teamName:String
    
    var body: some View {
        ZStack {
            
     
            Rectangle()
                .foregroundColor(.white)
                .cornerRadius(20)
                .shadow(color:.blue, radius:  5)
            
            VStack(alignment: .center) {
                HStack(alignment: .center) {
                    Spacer()
                    
                    
                   
                    InfoColumnView(team: game.HomeTeam, score: game.HomeTeamScore)
                    
                    
                    Spacer()
                    Text("VS")
                    Spacer()
                    
                    
                   
                    InfoColumnView(team: game.AwayTeam, score: game.AwayTeamScore)
                    Spacer()
                    
                }
               
                
                
                HStack {
                    Text(game.Status)
                    if (game.Status != "Final") {
                        if let dateTime = game.DateTime {
                            Text("@ " + DateHelper.getTimeString(time: dateTime))
                        }
                        
                    }
                }
                
                
                HStack {
                    Image(systemName: "star.square.fill")
                        .foregroundColor(.yellow)
                    Text(teamName)
                        .bold()
                }
                .padding(.top)
            }
            .padding()
        }
    }
}

struct FavouriteGameView_Previews: PreviewProvider {
    static var previews: some View {
        FavouriteGameView(game: Constants.pastGame, teamName: "")
    }
}
