//
//  FinalTeam.swift
//  ScoresApp
//
//  Created by Francis Shehata
//

import SwiftUI

struct FavoritePlayer: View {
    @ObservedObject var viewModel = RepoViewModel()
    @StateObject var d = DataModel()
    @State var teamName = ""
    var body: some View {
        
        VStack {
            List(viewModel.toDoList) { item in
                HStack{
                    HStack (spacing: 40){
                        Text(" Favorite Player: \(item.teamName)")
                        Spacer()
                    }
                    .accessibilityIdentifier("Player")
                    HStack{
                        Button(action: {
                            teamName = item.teamName
                            viewModel.toBeUpdatedToDo = item
                        }, label: {
                            Image(systemName: "pencil")
                        })
                        
                        
                        Button(action: {
                            viewModel.deleteToDo(todo: item)
                        }, label: {
                            Image(systemName: "trash")
                        })
                        
                    }
                    
                }
                
            }
            
            VStack(alignment: .center){
                HStack(alignment: .center){
                    TextField("Enter your Favorite Player", text: $teamName)
                        
                }
                Spacer()
                HStack(alignment: .center){
                    Button( action: {
                        let todo = Data(teamName: teamName)
                        
                        viewModel.addToDo(todo: todo)
                        
                    }, label: {
                        Text("Add Favorite Player")
                            
                    })
                    .accessibilityIdentifier("SubmitTeam")
                    
                }
            }
        }
    }
    
    
    struct FavoritePlayer_Previews: PreviewProvider {
        static var previews: some View {
            FavoritePlayer()
        }
    }
}
