//
//  DarkModeView.swift
//  ScoresApp
//
//  Created by Francis Shehata on 2022-12-08.
//

import SwiftUI

struct DarkModeView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DarkModeView_Previews: PreviewProvider {
    static var previews: some View {
        DarkModeView()
    }
}
