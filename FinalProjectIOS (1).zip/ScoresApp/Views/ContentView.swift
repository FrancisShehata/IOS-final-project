//
//  ContentView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct ContentView: View {
    @ObservedObject var model:DataModel
    var body: some View {
        ZStack {
            TabView {
                HomeView(model: model)
                    .tabItem {
                        VStack {
                            Image(systemName: "house")
                            Text("Home")
                        }
                    }
                
                ScheduleView(model: model)
                    .tabItem {
                        VStack {
                            Image(systemName: "sportscourt")
                            Text("Scores")
                        }
                    }
                StandingsView(model: model)
                    .tabItem {
                        VStack {
                            Image(systemName: "person.fill")
                            Text("Standings")
                        }
                    }
                SettingsView(model: model)
                    .tabItem {
                        VStack {
                            Image(systemName: "gearshape")
                            Text("Settings")
                        }
                    }
                
                FavoritePlayer()
                    .tabItem {
                        VStack {
                            Image(systemName: "person.fill")
                            Text("Players")
                        }
                    }
                    .accessibilityIdentifier("FinalTeam")
                
                
            }
        }
        
        
        
        
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView(model: DataModel())
        }
    }
}
