//
//  DarkMode.swift
//  ScoresApp
//
//  Created by Francis Shehata on 2022-12-02.
//

import SwiftUI

struct DarkMode: View {
    var body: some View {
        NavigationView{
            
        }
        .toolbar{
            ToolbarItem(placement: ToolbarItemPlacement.navigationBarTrailing){
                Button(action: {}, label: { isDark ? Label("Dark", systemImage: "lightbulb.fill"): Label("Dark", systemImage: "lightbulb")
            }
        }
    }
}

struct DarkMode_Previews: PreviewProvider {
    static var previews: some View {
        DarkMode()
    }
  }
}
