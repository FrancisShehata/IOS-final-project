//
//  SettingsView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct SettingsView: View {
   
    @ObservedObject var model:DataModel
    @State private var isOn = false
    @State private var darkmode:Bool = false
    @State private var currentmode:ColorScheme = .light
    var body: some View {
        ZStack {
            
            
            Color("backdrop")
                .ignoresSafeArea()
            
            VStack{
                HStack{
                    Text("Settings")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    Image("nba")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 80, height: 60, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                }
                VStack{
                    Form{
                        Toggle("Dark Mode", isOn: $darkmode)
                            .onChange(of: darkmode) { value in
                                if darkmode == true {
                                    currentmode = .dark
                                    
                                } else{
                                    currentmode = .light
                                }
                            }
                            .preferredColorScheme(currentmode)
                    }
                    Spacer()
                    
                    VStack(alignment: .center) {
                        Text("Favorite Team:")
                        Picker(selection: $model.favouriteTeam, label: Text(""), content: {
                            ForEach(0..<Constants.teams.count) { i in
                                Text(Constants.teamNames[i]).tag(i)
                            }
                        })
                    }
                    Spacer()
                }
                .padding(.horizontal)
            }
        }
        
    }
    
    struct SettingsView_Previews: PreviewProvider {
        static var previews: some View {
            SettingsView(model: DataModel())
        }
    }
    
}
