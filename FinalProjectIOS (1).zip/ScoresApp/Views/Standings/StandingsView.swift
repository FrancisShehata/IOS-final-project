//
//  StandingsView.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI

struct StandingsView: View {
    
   
    @ObservedObject var model:DataModel
    
    @State var selectedConf = "east"
    
    var body: some View {
        if let standings = model.standings {
            ZStack {
        
                Color("backdrop")
                    .ignoresSafeArea()
                
                ScrollView {
                    VStack(alignment: .leading) {
                        
                       
                        HStack{
                            Text("Standings")
                                .font(.largeTitle)
                                .bold()
                            Spacer()
                            Image("nba")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 70, height: 60, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        }
                        
                   
                        Picker(selection: $selectedConf, label: Text(""), content: {
                            Text("East").tag("east")
                            Text("West").tag("west")
                        })
                        .pickerStyle(SegmentedPickerStyle())
                    }.padding(.horizontal)
                    Divider()
                    
                    
                
                    HStack{
                        Text("#")
                            .bold()
                            .frame(width: 25, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                        Text("Team")
                            .bold()
                            .frame(width: 45, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                        Spacer()
                        
                        Text("W - L")
                            .bold()
                            .frame(width: 75, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        
                    }
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                    
                    Divider()
        
                    if selectedConf == "east" {
                        ConferenceStandingsView(teams: standings.east, favouriteTeamID: model.favouriteTeam)
                    } else {
                        ConferenceStandingsView(teams: standings.west, favouriteTeamID: model.favouriteTeam)
                    }
                    
                }
            }
        }
        
    }
    
    
    init(model: DataModel) {
        self.model = model
        UISegmentedControl.appearance().selectedSegmentTintColor = .red
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.white], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.black
        ], for: .normal)
    }
}


struct StandingsView_Previews: PreviewProvider {
    static var previews: some View {
        StandingsView(model: DataModel())
    }
}
