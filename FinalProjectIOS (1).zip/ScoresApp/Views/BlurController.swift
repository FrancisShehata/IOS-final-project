//
//  BlurController.swift
//  ScoresApp
//
//  Created by Francis Shehata on 2022-12-08.
//

import Foundation
import UIKit

class ViewController: UIViewController{
    
    @IBOutlet var HomeView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let blur = UIBlurEffect(style: .regular)
           let effectView = UIVisualEffectView(effect: blur)
           effectView.frame = view.bounds
           effectView.alpha = 1
           view.addSubview(HomeView)
    }
   
}
