//
//  HomeView.swift
//  ScoresApp
//
//  Created by Francis Shehata on 2022-12-06.
//

import SwiftUI

struct HomeView: View {
    @ObservedObject var model:DataModel
    var body: some View {
        
        VStack{
            Spacer(minLength: 60)
            Text("Nba App")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.black)
                .shadow(color: .red, radius: 2.2, x: 8, y: 5)
                
            Spacer()
            Image("lebron")
                .resizable()
                .scaledToFit()
                .frame(width: 800, height: 700, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .blur(radius: 1.0)
            Spacer()
        }
        
    }
    
    
    struct HomeView_Previews: PreviewProvider {
        static var previews: some View {
            HomeView(model: DataModel())
        }
    }
}
