//
//  ScoresApp.swift
//  ScoresApp
//
//  Created by Francis Shehata


import SwiftUI
import Firebase

@main
struct ScoresApp: App {
    
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        
        WindowGroup {
            ContentView(model: DataModel())
        }
    }
}
