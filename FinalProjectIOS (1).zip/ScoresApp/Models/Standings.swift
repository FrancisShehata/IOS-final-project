//
//  Standings.swift
//  ScoresApp
//
//  Created by Francis Shehata


import Foundation

struct Standings: Decodable {
    var teams:[Team]
    
    var east:[Team]
    var west:[Team]
    
    init() {
        self.teams = [Team]()
        self.east = [Team]()
        self.west = [Team]()
    }
    
 
    mutating func sortConferences() {
        
        for t in (0..<teams.count) {
            if teams[t].Conference == "Eastern" {
                self.east.append(teams[t])
            } else {
                self.west.append(teams[t])
            }
        }
        
        self.east.sort { t1, t2 in
            return t1.Percentage > t2.Percentage
        }
        
        self.west.sort { t1, t2 in
            return t1.Percentage > t2.Percentage
        }
    }
}

struct Team: Decodable, Identifiable {
    var id:UUID?
    var Key:String
    var City:String
    var Name:String
    var Conference:String
    var TeamID:Int
    var Wins:Int
    var Losses:Int
    var Percentage:Double
    var ConferenceRank:Int
}
