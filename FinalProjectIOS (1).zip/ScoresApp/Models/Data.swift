//
//  Data.swift
//  ScoresApp
//
//  Created by Francis Shehata on 2022-12-08.
//


import FirebaseFirestoreSwift

struct Data: Identifiable, Codable{
    @DocumentID var id: String?

    var teamName: String = ""
 

    init(){
        
    }

    init(teamName:String){
        self.teamName = teamName
        

    }
}

