//
//  Repo.swift
//  ScoresApp
//
//  Created by Francis Shehata 
//

import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class Repo: ObservableObject {

    static var shared = Repo()

    @Published var list: [Data] = []

    private let path = "Favorite Player"
    private let store = Firestore.firestore()

    init() {
        get()
    }


    func get() {
        store.collection(path).addSnapshotListener { snapshot, error in

            if let error = error {
                print(error)
                return
            }

            self.list = snapshot?.documents.compactMap{
                try? $0.data(as: Data.self)
            } ?? []
        }
    }


    func add( todo: Data){
        do{
              try store.collection(path).addDocument(from: todo)
        } catch {
            print(error)
        }
    }


    func delete( todo: Data){
        if let documentId = todo.id {
            store.collection(path).document(documentId).delete() { error in
                if let error = error {
                    print(error.localizedDescription)
                }
            }
        }
    }


    func update( todo:Data){
        if let documentId = todo.id{
            store.collection(path).document(documentId).setData(["Favorite Player": todo.teamName], merge: true)
        }
    }


}
